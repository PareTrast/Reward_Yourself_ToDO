# c:\Users\nrmlc\OneDrive\Desktop\Reward_Yourself_ToDO\user_manager.py
import flet as ft
import os
import sys
import traceback
import json
import requests
from requests.exceptions import RequestException, HTTPError

# --- Only import supabase client parts if NOT in web environment ---
if "pyodide" not in sys.modules:
    from supabase import create_client, Client
    from supabase.lib.client_options import ClientOptions
else:
    # Define dummy types for type hinting in web environment if needed
    class Client:
        pass

    class ClientOptions:
        pass

    # Import js for web environment
    import js
# --- End Conditional Import ---

from user_storage import FileSystemUserStorage
from dotenv import load_dotenv
import config_loader

load_dotenv()

print("Running in web environment:", "pyodide" in sys.modules)


class UserManager:
    def __init__(self, page: ft.Page, users_dir="users"):
        self.page = page
        self.users_dir = users_dir
        # User storage might still be needed for non-web token storage
        self.user_storage = self.get_user_storage()
        self.supabase_url = config_loader.get_supabase_url()
        self.supabase_anon_key = config_loader.get_supabase_anon_key()

        # --- Initialize clients only if NOT web ---
        self.admin_supabase: Client | None = None
        self.public_supabase: Client | None = None
        if not self.page.web:
            self.supabase_service_role_key = os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
            # Try initializing clients immediately for non-web
            self.get_admin_supabase_client()
            self.get_supabase_client()
        # --- End Conditional Initialization ---

        print(f"UserManager - URL Loaded: {self.supabase_url is not None}")
        print(f"UserManager - Anon Key Loaded: {self.supabase_anon_key is not None}")
        if not self.page.web:
            print(
                f"UserManager - Service Key Loaded: {self.supabase_service_role_key is not None}"
            )
        print(f"UserManager - Running in web environment: {self.page.web}")
        if config_loader.CONFIG_ERROR:
            print(
                f"UserManager - Warning: Configuration error detected: {config_loader.CONFIG_ERROR}"
            )

    def get_user_storage(self):
        # This might only be relevant for non-web if web uses client_storage
        # Keep it for now, assuming FileSystemUserStorage might still be used
        # for non-web token persistence if session.json isn't the primary method.
        return FileSystemUserStorage(self.users_dir)

    # --- Refactor register_user ---
    async def register_user(self, username, password):
        """Registers a new user using Supabase JS SDK (web) or REST API (non-web)."""
        if not self.supabase_url or not self.supabase_anon_key:
            print("Error: Supabase URL or Anon Key not configured for registration.")
            return None, None, None

        email = f"{username}@placeholder.com"

        if self.page.web:
            # --- Web Path: Use JavaScript ---
            print(f"Python (Web): Calling jsSignUp for {email}")
            try:
                # Ensure the JS function exists before calling
                if not hasattr(js, "jsSignUp"):
                    print(
                        "Error: jsSignUp function not found in JavaScript environment."
                    )
                    return None, None, None

                # Call the async JS function and await its result
                result_proxy = await js.jsSignUp(email, password, username)
                # Convert the Pyodide proxy object to a Python dict
                result = result_proxy.to_py()
                print(f"Python (Web): Received from jsSignUp: {result}")

                if result and result.get("error"):
                    print(f"Python (Web): Error from jsSignUp: {result['error']}")
                    # Handle specific errors like 'Confirmation required' if needed
                    return None, None, None  # Or return specific error info
                elif result and result.get("access_token"):
                    print("Python (Web): jsSignUp successful.")
                    return (
                        result.get("access_token"),
                        result.get("user_id"),
                        result.get("refresh_token"),
                    )
                else:
                    print("Python (Web): Unexpected result structure from jsSignUp.")
                    return None, None, None

            except Exception as e:
                print(f"Python (Web): Error calling or processing jsSignUp: {e}")
                traceback.print_exc()
                return None, None, None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use REST API (Existing Logic) ---
            print(f"Python (Non-Web): Registering user {email} via REST API")
            signup_url = f"{self.supabase_url}/auth/v1/signup"
            headers = {
                "apikey": self.supabase_anon_key,
                "Content-Type": "application/json",
            }
            payload = {
                "email": email,
                "password": password,
                "options": {"data": {"username": username, "user_medal_count": 0}},
            }
            try:
                response = requests.post(
                    signup_url, headers=headers, json=payload, timeout=15
                )
                response.raise_for_status()
                data = response.json()
                print(f"Register response (Non-Web): {data}")
                user_info = data.get("user", {})
                access_token = data.get("access_token")
                user_id = user_info.get("id")
                refresh_token = data.get("refresh_token")
                # Handle cases where signup requires confirmation (no session returned)
                if user_info and not access_token:
                    print(
                        "Registration (Non-Web): User created but may require confirmation."
                    )
                    # Decide how to handle this - maybe return user_id but no tokens
                    # For now, align with JS and treat as failure if no token
                    return None, user_id, None  # Indicate confirmation needed?
                return access_token, user_id, refresh_token
            except HTTPError as e:
                print(
                    f"Error during registration (Non-Web) (HTTP {e.response.status_code}): {e.response.text}"
                )
                # ... (keep existing HTTP error handling) ...
                return None, None, None
            except requests.exceptions.Timeout:
                print(f"Timeout Error during registration (Non-Web): {signup_url}")
                return None, None, None
            except RequestException as e:
                print(f"Network error during registration (Non-Web): {e}")
                return None, None, None
            except Exception as e:
                print(f"Unexpected error during registration (Non-Web): {e}")
                traceback.print_exc()
                return None, None, None
            # --- End Non-Web Path ---

    # --- Refactor verify_user ---
    async def verify_user(self, username, password):
        """Verifies credentials using Supabase JS SDK (web) or REST API (non-web)."""
        print("--- verify_user called ---")
        if not self.supabase_url or not self.supabase_anon_key:
            print("Error: Supabase URL or Anon Key not configured for verification.")
            return None, None, None

        email = f"{username}@placeholder.com"

        if self.page.web:
            # --- Web Path: Use JavaScript ---
            print(f"Python (Web): Calling jsSignIn for {email}")
            try:
                # Ensure the JS function exists
                if not hasattr(js, "jsSignIn"):
                    print(
                        "Error: jsSignIn function not found in JavaScript environment."
                    )
                    return None, None, None

                result_proxy = await js.jsSignIn(email, password)
                result = result_proxy.to_py()
                print(f"Python (Web): Received from jsSignIn: {result}")

                if result and result.get("error"):
                    print(f"Python (Web): Error from jsSignIn: {result['error']}")
                    return None, None, None
                elif result and result.get("access_token"):
                    print("Python (Web): jsSignIn successful.")
                    return (
                        result.get("access_token"),
                        result.get("user_id"),
                        result.get("refresh_token"),
                    )
                else:
                    print("Python (Web): Unexpected result structure from jsSignIn.")
                    return None, None, None

            except Exception as e:
                print(f"Python (Web): Error calling or processing jsSignIn: {e}")
                traceback.print_exc()
                return None, None, None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use REST API (Existing Logic) ---
            print(f"Python (Non-Web): Verifying user {email} via REST API")
            token_url = f"{self.supabase_url}/auth/v1/token?grant_type=password"
            headers = {
                "apikey": self.supabase_anon_key,
                "Content-Type": "application/json",
            }
            payload = {"email": email, "password": password}
            print(f"Login URL (Non-Web): {token_url}")
            try:
                response = requests.post(
                    token_url, headers=headers, json=payload, timeout=15
                )
                print(f"Login Raw Response Status (Non-Web): {response.status_code}")
                response.raise_for_status()
                data = response.json()
                access_token = data.get("access_token")
                user_info = data.get("user", {})
                user_id = user_info.get("id")
                refresh_token = data.get("refresh_token")
                print(f"Extracted access_token (Non-Web): {access_token is not None}")
                print(f"Extracted user_id (Non-Web): {user_id}")
                print(f"Extracted refresh_token (Non-Web): {refresh_token is not None}")
                return access_token, user_id, refresh_token
            except HTTPError as e:
                # ... (keep existing HTTP error handling) ...
                if e.response.status_code == 400:
                    error_detail = "Invalid credentials or user not found"
                    try:
                        error_json = e.response.json()
                        if "Email not confirmed" in error_json.get(
                            "error_description", ""
                        ):
                            error_detail = "Email not confirmed"
                    except json.JSONDecodeError:
                        pass
                    print(f"Login failed (Non-Web): {error_detail} (HTTP 400).")
                else:
                    print(
                        f"Error during login (Non-Web) (HTTP {e.response.status_code}): {e.response.text}"
                    )
                return None, None, None
            except requests.exceptions.Timeout:
                print(f"Timeout Error during login (Non-Web): {token_url}")
                return None, None, None
            except RequestException as e:
                print(f"Network error during login (Non-Web): {e}")
                return None, None, None
            except Exception as e:
                print(f"Unexpected error during login (Non-Web): {e}")
                traceback.print_exc()
                return None, None, None
            # --- End Non-Web Path ---

    # --- Refactor get_supabase_client ---
    def get_supabase_client(self) -> Client | None:
        """Returns a synchronous Supabase client (non-web only)."""
        if self.page.web:
            print(
                "Warning: get_supabase_client called in web environment. Returning None."
            )
            return None

        # --- Non-Web Logic ---
        if (
            "pyodide" in sys.modules
        ):  # Should not happen if page.web is False, but safety check
            print("Error: Attempting to create supabase-py client in web env.")
            return None

        if not self.supabase_url or not self.supabase_anon_key:
            print(
                "Error: Cannot create public Supabase client (Non-Web). URL or Anon Key missing."
            )
            return None
        if self.public_supabase is None:
            try:
                client_options = ClientOptions(auto_refresh_token=True, schema="public")
                self.public_supabase = create_client(
                    self.supabase_url,
                    self.supabase_anon_key,
                    options=client_options,
                )
                print(
                    "Public synchronous Supabase client created (schema: public) (Non-Web)."
                )
            except Exception as e:
                print(f"Error creating public Supabase client (Non-Web): {e}")
                traceback.print_exc()
                return None
        return self.public_supabase
        # --- End Non-Web Logic ---

    # --- Refactor get_admin_supabase_client ---
    def get_admin_supabase_client(self) -> Client | None:
        """Returns a synchronous Supabase admin client (non-web only)."""
        if self.page.web:
            print(
                "Warning: get_admin_supabase_client called in web environment. Returning None."
            )
            return None

        # --- Non-Web Logic ---
        if "pyodide" in sys.modules:
            print("Error: Attempting to create supabase-py admin client in web env.")
            return None

        if (
            not hasattr(self, "supabase_service_role_key")
            or not self.supabase_service_role_key
        ):
            print(
                "Warning: SUPABASE_SERVICE_ROLE_KEY not set. Cannot create admin client (Non-Web)."
            )
            return None
        if not self.supabase_url:
            print("Error: Cannot create admin Supabase client (Non-Web). URL missing.")
            return None
        if self.admin_supabase is None:
            try:
                client_options = ClientOptions(schema="auth")
                self.admin_supabase = create_client(
                    self.supabase_url,
                    self.supabase_service_role_key,
                    options=client_options,
                )
                print(
                    "Admin synchronous Supabase client created (schema: auth) (Non-Web)."
                )
            except Exception as e:
                print(f"Error creating admin Supabase client (Non-Web): {e}")
                traceback.print_exc()
                return None
        return self.admin_supabase
        # --- End Non-Web Logic ---

    # --- Refactor get_user_metadata_admin ---
    def get_user_metadata_admin(self, user_id: str) -> dict | None:
        """Fetches user metadata using admin client (non-web only)."""
        if self.page.web:
            print(
                "Error: get_user_metadata_admin cannot be called in web environment for security reasons."
            )
            return None  # Or raise an exception

        # --- Non-Web Logic ---
        print(
            f"--- get_user_metadata_admin called for user_id: {user_id} (Non-Web) ---"
        )
        admin_client = self.get_admin_supabase_client()
        if not admin_client:
            print("Error: Admin client not available to fetch metadata (Non-Web).")
            return None

        try:
            print(
                f"Querying 'users' table (in auth schema) for id: {user_id} (Non-Web)"
            )
            response = (
                admin_client.from_("users")
                .select("raw_user_meta_data")
                .eq("id", user_id)
                .single()
                .execute()
            )
            print(f"Admin query response data (Non-Web): {response.data}")

            if response.data:
                metadata = response.data.get("raw_user_meta_data")
                if isinstance(metadata, dict):
                    print(
                        f"Successfully fetched metadata via admin (Non-Web): {metadata}"
                    )
                    return metadata
                elif metadata is None:
                    print(
                        f"User {user_id} found, but 'raw_user_meta_data' is null (Non-Web)."
                    )
                    return {}
                else:
                    print(
                        f"Warning: 'raw_user_meta_data' field is not a dictionary or is missing (Non-Web): {metadata}"
                    )
                    return None
            else:
                print(
                    f"No user found or unexpected response structure for ID {user_id} via admin query (Non-Web)."
                )
                return None

        except Exception as e:
            print(
                f"Error querying auth.users via admin client (Non-Web) (using .single()): {e}"
            )
            traceback.print_exc()
            return None
        # --- End Non-Web Logic ---

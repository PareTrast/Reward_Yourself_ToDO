# c:\Users\nrmlc\OneDrive\Desktop\Reward_Yourself_ToDO\todo_view.py
import datetime
import sys  # Keep sys for checking environment
import requests  # Keep requests for non-web path
from requests.exceptions import RequestException, HTTPError, Timeout
import json
import config_loader
import traceback

# --- Conditional Imports ---
if "pyodide" not in sys.modules:
    from supabase import Client

    # Import Supabase/PostgREST exceptions if needed for specific checks
    from postgrest import APIError as PostgrestAPIError
    from gotrue.errors import AuthApiError
else:
    # Define dummy types for type hinting in web environment if needed
    class Client:
        pass

    class PostgrestAPIError(Exception):
        pass

    class AuthApiError(Exception):
        pass

    # Import js for web environment
    import js
# --- End Conditional Imports ---


# Get config values from the loader
SUPABASE_URL = config_loader.get_supabase_url()
SUPABASE_KEY = config_loader.get_supabase_anon_key()  # This is the Anon Key

# Check if loading failed
if config_loader.CONFIG_ERROR:
    print(
        f"ToDoList - Warning: Configuration error detected: {config_loader.CONFIG_ERROR}"
    )
    # Handle error appropriately - maybe raise an exception or disable functionality

# --- Constants ---
MEDALS_PER_TASK = 1  # Define how many medals a task is worth

# Keep the print statement for debugging if needed
print(
    f"ToDoList - Using API Key (Anon): {'*' * (len(SUPABASE_KEY) - 5) + SUPABASE_KEY[-5:] if SUPABASE_KEY else 'Not Set'}"
)
print(f"ToDoList - Using API URL: {SUPABASE_URL}")


class ToDoList:
    # --- Modify __init__ ---
    def __init__(
        self,
        username,
        is_web_environment,
        supabase_client: Client | None,  # Allow None for web
    ):
        self.username = username
        self.is_web_environment = is_web_environment
        # api_url/rpc_url only needed for non-web _make_request
        self.api_url = f"{SUPABASE_URL}/rest/v1" if SUPABASE_URL else None
        self.rpc_url = f"{SUPABASE_URL}/rest/v1/rpc" if SUPABASE_URL else None
        self.access_token = None
        self.user_id = None  # Will be set later
        self.refresh_token = None
        # requests.Session only needed for non-web _make_request
        self.session = requests.Session() if not self.is_web_environment else None
        # supabase_client only needed for non-web get_medal_count
        self.supabase_client = supabase_client if not self.is_web_environment else None

        if not self.is_web_environment:
            if not self.api_url:
                print("ToDoList Error (Non-Web): API URL is not configured.")
            if not self.rpc_url:
                print("ToDoList Error (Non-Web): RPC URL is not configured.")
            if not self.supabase_client:
                # This might be okay if login hasn't happened yet, but log warning
                print(
                    "ToDoList Warning (Non-Web): Supabase client not provided at init."
                )
        else:
            # Check JS functions exist in web environment
            required_js_funcs = [
                "jsGetMedalCount",
                "jsUpdateMedalCountRpc",
                "jsGetAllTasks",
                "jsAddNewTask",
                "jsAddTaskHistory",
                "jsDeleteTask",
                "jsGetAllRewards",
                "jsAddNewReward",
                "jsAddRewardHistory",
                "jsDeleteReward",
                "jsGetTaskHistory",
                "jsGetRewardHistory",
            ]
            missing_funcs = [f for f in required_js_funcs if not hasattr(js, f)]
            if missing_funcs:
                print(
                    f"ToDoList Error (Web): Missing required JavaScript functions: {', '.join(missing_funcs)}"
                )
                # Consider raising an error or setting an error state

    # --- End modification ---

    def set_access_token(self, access_token, refresh_token=None):
        """Sets the access token for API calls and updates the session headers."""
        self.access_token = access_token
        if refresh_token:
            self.refresh_token = refresh_token

        if not SUPABASE_KEY:
            print("ToDoList Error: Supabase Anon Key not configured.")
            return

        # --- Conditional Header/Client Update ---
        if not self.is_web_environment:
            if self.session:
                # Update requests session headers (for direct REST calls via _make_request)
                self.session.headers.update(
                    {
                        "Authorization": f"Bearer {self.access_token}",
                        "apikey": SUPABASE_KEY,
                        "Content-Type": "application/json",
                        "Prefer": "return=representation",
                    }
                )
                print("Access token set in requests session headers (Non-Web).")
            else:
                print(
                    "Warning (Non-Web): requests.Session not initialized in set_access_token."
                )

            # ALSO set session in the supabase-py client instance
            if self.supabase_client and self.access_token and self.refresh_token:
                try:
                    self.supabase_client.auth.set_session(
                        self.access_token, self.refresh_token
                    )
                    print("Session set in supabase-py client (Non-Web).")
                except Exception as e:
                    print(f"Error setting session in supabase-py client (Non-Web): {e}")
            elif not self.supabase_client:
                print(
                    "Warning (Non-Web): supabase_client not available in set_access_token."
                )
        else:
            # In web, supabase-js handles token management internally after sign-in.
            # We just need the token for potential direct fetch calls if we weren't using wrappers.
            # For now, just store it. The JS wrappers will use the supabase-js client's state.
            print("Access token stored for potential use (Web).")
        # --- End Conditional Update ---

    # _make_request is only used by the non-web path now
    def _make_request(self, method, endpoint, base_url=None, **kwargs):
        """Helper method for making synchronous requests (Data or RPC) via requests library (NON-WEB ONLY)."""
        if self.is_web_environment:
            print("Error: _make_request should not be called in web environment.")
            return None  # Or raise an error

        if config_loader.CONFIG_ERROR:
            print(
                f"Error (Non-Web): Cannot make request due to config error: {config_loader.CONFIG_ERROR}"
            )
            return None

        current_base_url = base_url if base_url else self.api_url
        if not current_base_url:
            print(
                f"Error (Non-Web): Base URL ({'RPC' if base_url else 'Data'}) not configured."
            )
            return None

        if not self.access_token:
            print("Error (Non-Web): Access token not set for API call.")
            return None
        if not self.session:
            print("Error (Non-Web): requests.Session not initialized.")
            return None

        url = f"{current_base_url}/{endpoint}"
        headers = self.session.headers  # Use headers from session

        print(f"Making {method} request to: {url} (Non-Web)")
        try:
            response = self.session.request(  # Use session.request
                method, url, timeout=15, **kwargs
            )
            print(f"Response Status (Non-Web): {response.status_code}")
            response.raise_for_status()

            if response.status_code == 204:
                return True
            if not response.content:
                if method == "GET":
                    return []
                if method == "POST" and response.status_code == 201:
                    print(
                        f"Warning (Non-Web): POST to {endpoint} returned 201 but empty body."
                    )
                    return {}
                # Handle RPC empty body case if needed, though JS version expects JSON
                return True  # Or handle specific cases
            return response.json()

        except HTTPError as e:
            print(
                f"HTTP Error (Non-Web) during {method} {url}: {e.response.status_code} - {e.response.text}"
            )
            if e.response.status_code == 401:
                print("Authorization Error (401): Token might be expired or invalid.")
            return None
        except requests.exceptions.Timeout:
            print(f"Timeout Error (Non-Web) during {method} {url}")
            return None
        except RequestException as e:
            print(f"Network Error (Non-Web) during {method} {url}: {e}")
            return None
        except json.JSONDecodeError as e:
            print(
                f"JSON Decode Error (Non-Web) during {method} {url}: {e} - Response: {response.text[:200]}"
            )
            return None
        except Exception as e:
            print(f"Unexpected error (Non-Web) during {method} {url}: {e}")
            traceback.print_exc()
            return None

    # --- Refactor get_medal_count ---
    async def get_medal_count(self):
        """Fetches the current user's medal count. Uses JS SDK (web) or supabase-py client (non-web)."""
        print("--- get_medal_count called ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print("Python (Web): Calling jsGetMedalCount...")
            try:
                if not hasattr(js, "jsGetMedalCount"):
                    print("Error (Web): jsGetMedalCount function not found.")
                    return None
                result_proxy = await js.jsGetMedalCount()
                result = result_proxy.to_py()
                print(f"Python (Web): Received from jsGetMedalCount: {result}")
                if result and result.get("error"):
                    print(
                        f"Python (Web): Error from jsGetMedalCount: {result['error']}"
                    )
                    return None
                elif result and result.get("data") is not None:
                    # Ensure it's an integer
                    try:
                        count = int(result["data"])
                        print(f"Python (Web): Medal count: {count}")
                        return count
                    except (ValueError, TypeError):
                        print(
                            f"Python (Web): Invalid count format received: {result['data']}"
                        )
                        return None  # Or maybe 0?
                else:
                    print(
                        "Python (Web): Unexpected result structure from jsGetMedalCount."
                    )
                    return None
            except Exception as e:
                print(f"Python (Web): Error calling or processing jsGetMedalCount: {e}")
                traceback.print_exc()
                return None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use supabase-py client (Existing Logic) ---
            print("Python (Non-Web): Getting medal count via supabase-py client...")
            if not self.supabase_client:
                print("Error (Non-Web): Supabase client not available.")
                return None
            # ... (Keep the existing non-web logic using self.supabase_client) ...
            # This part seems complex and prone to errors in the original code.
            # Ensure the original logic using query.execute() is robust.
            # For brevity, assuming the original non-web logic is retained here.
            # Simplified version of the original non-web logic:
            current_user_id = self.user_id
            if not current_user_id:
                try:
                    user_response = self.supabase_client.auth.get_user()
                    if user_response and user_response.user:
                        current_user_id = user_response.user.id
                        self.user_id = current_user_id
                    else:
                        return None
                except Exception as auth_e:
                    print(f"Error fetching user ID (Non-Web): {auth_e}")
                    return None

            try:
                response = (
                    self.supabase_client.table("user_profiles")
                    .select("medal_count")
                    .eq("id", current_user_id)
                    .maybe_single()
                    .execute()
                )
                if response and response.data is not None:
                    count = response.data.get("medal_count", 0)
                    return int(count)
                elif response and response.data is None:  # Profile not found
                    print(
                        f"No profile found for user {current_user_id} (Non-Web). Creating..."
                    )
                    insert_response = (
                        self.supabase_client.table("user_profiles")
                        .insert({"id": current_user_id, "medal_count": 0})
                        .execute()
                    )
                    if insert_response and insert_response.data:
                        return 0
                    else:
                        print(
                            f"Failed to insert profile (Non-Web). Response: {insert_response}"
                        )
                        return None  # Failed insert
                else:  # Handle case where response itself is None or unexpected
                    print(
                        f"Unexpected response from profile fetch (Non-Web): {response}"
                    )
                    return None
            except Exception as e:
                print(f"Error fetching/creating profile (Non-Web): {e}")
                traceback.print_exc()
                return None
            # --- End Non-Web Path ---

    # --- Refactor _update_medal_count_rpc ---
    async def _update_medal_count_rpc(self, amount_to_add):
        """Updates medal count via RPC. Uses JS SDK (web) or _make_request (non-web)."""
        print(f"--- _update_medal_count_rpc called with amount: {amount_to_add} ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print(
                f"Python (Web): Calling jsUpdateMedalCountRpc with amount: {amount_to_add}"
            )
            try:
                if not hasattr(js, "jsUpdateMedalCountRpc"):
                    print("Error (Web): jsUpdateMedalCountRpc function not found.")
                    return None
                result_proxy = await js.jsUpdateMedalCountRpc(amount_to_add)
                result = result_proxy.to_py()
                print(f"Python (Web): Received from jsUpdateMedalCountRpc: {result}")
                if result and result.get("error"):
                    print(
                        f"Python (Web): Error from jsUpdateMedalCountRpc: {result['error']}"
                    )
                    return None
                elif result and result.get("data") is not None:
                    try:
                        new_count = int(result["data"])
                        print(f"Python (Web): RPC successful. New count: {new_count}")
                        return new_count
                    except (ValueError, TypeError):
                        print(
                            f"Python (Web): Invalid new count format from RPC: {result['data']}"
                        )
                        return None
                else:
                    print(
                        "Python (Web): Unexpected result structure from jsUpdateMedalCountRpc."
                    )
                    return None
            except Exception as e:
                print(
                    f"Python (Web): Error calling or processing jsUpdateMedalCountRpc: {e}"
                )
                traceback.print_exc()
                return None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request (Existing Logic) ---
            print(f"Python (Non-Web): Updating medal count via _make_request RPC...")
            if not self.rpc_url:
                print("Error (Non-Web): RPC URL not set.")
                return None
            if not self.access_token:
                print("Error (Non-Web): Access token not set.")
                return None

            endpoint = "increment_user_medal_count"
            payload = {"amount_param": amount_to_add}
            response_data = self._make_request(
                "POST", endpoint, base_url=self.rpc_url, json=payload
            )

            # Process non-web response
            if response_data is None:
                return None
            elif isinstance(response_data, dict) and response_data.get("success"):
                new_count = response_data.get("new_medal_count")
                if isinstance(new_count, int):
                    return new_count
                else:
                    print(f"RPC success but invalid count (Non-Web): {new_count}")
                    return None
            else:
                error_msg = (
                    response_data.get("error", "Unknown RPC error")
                    if isinstance(response_data, dict)
                    else "Invalid RPC response format"
                )
                print(f"Failed RPC (Non-Web): {error_msg}")
                return None
            # --- End Non-Web Path ---

    # --- Refactor get_all_tasks ---
    async def get_all_tasks(self):
        """Fetches all tasks. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- get_all_tasks called ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print("Python (Web): Calling jsGetAllTasks...")
            try:
                if not hasattr(js, "jsGetAllTasks"):
                    print("Error (Web): jsGetAllTasks function not found.")
                    return []
                result_proxy = await js.jsGetAllTasks()
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(f"Python (Web): Error from jsGetAllTasks: {result['error']}")
                    return []
                elif result and result.get("data") is not None:
                    tasks = result["data"]
                    print(f"Python (Web): Fetched {len(tasks)} tasks.")
                    return tasks if isinstance(tasks, list) else []
                else:
                    print("Python (Web): Unexpected result from jsGetAllTasks.")
                    return []
            except Exception as e:
                print(f"Python (Web): Error calling jsGetAllTasks: {e}")
                traceback.print_exc()
                return []
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print("Python (Non-Web): Getting tasks via _make_request...")
            endpoint = "tasks"
            params = {"select": "*"}
            data = self._make_request("GET", endpoint, params=params)
            return data if isinstance(data, list) else []
            # --- End Non-Web Path ---

    # --- Refactor add_new_task ---
    async def add_new_task(self, task_data):
        """Adds a new task. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- add_new_task called ---")
        if not self.username:
            print("Error: Username not set.")
            return None
        task_data["username"] = self.username  # Add username if needed by table/RLS

        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print(f"Python (Web): Calling jsAddNewTask with data: {task_data}")
            try:
                if not hasattr(js, "jsAddNewTask"):
                    print("Error (Web): jsAddNewTask function not found.")
                    return None
                # Convert Python dict to JS object if necessary (Pyodide often handles this)
                # js_task_data = js.Object.from_py(task_data)
                result_proxy = await js.jsAddNewTask(task_data)
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(f"Python (Web): Error from jsAddNewTask: {result['error']}")
                    return None
                elif result and result.get("data") is not None:
                    print("Python (Web): Task added successfully.")
                    # Return the first item from the data array if it exists
                    return (
                        result["data"][0]
                        if isinstance(result["data"], list) and result["data"]
                        else {}
                    )
                else:
                    print("Python (Web): Unexpected result from jsAddNewTask.")
                    return None
            except Exception as e:
                print(f"Python (Web): Error calling jsAddNewTask: {e}")
                traceback.print_exc()
                return None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print(f"Python (Non-Web): Adding task via _make_request: {task_data}")
            endpoint = "tasks"
            response_data = self._make_request("POST", endpoint, json=task_data)
            if response_data is not None:
                print("Task added successfully (Non-Web).")
                return response_data
            else:
                print("Failed to add task (Non-Web).")
                return None
            # --- End Non-Web Path ---

    # --- Refactor get_all_rewards ---
    async def get_all_rewards(self):
        """Fetches all rewards. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- get_all_rewards called ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print("Python (Web): Calling jsGetAllRewards...")
            try:
                if not hasattr(js, "jsGetAllRewards"):
                    print("Error (Web): jsGetAllRewards function not found.")
                    return []
                result_proxy = await js.jsGetAllRewards()
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(
                        f"Python (Web): Error from jsGetAllRewards: {result['error']}"
                    )
                    return []
                elif result and result.get("data") is not None:
                    rewards = result["data"]
                    print(f"Python (Web): Fetched {len(rewards)} rewards.")
                    return rewards if isinstance(rewards, list) else []
                else:
                    print("Python (Web): Unexpected result from jsGetAllRewards.")
                    return []
            except Exception as e:
                print(f"Python (Web): Error calling jsGetAllRewards: {e}")
                traceback.print_exc()
                return []
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print("Python (Non-Web): Getting rewards via _make_request...")
            endpoint = "rewards"
            params = {"select": "*"}
            data = self._make_request("GET", endpoint, params=params)
            print(f"Fetched Rewards from API (Non-Web): {data}")
            return data if isinstance(data, list) else []
            # --- End Non-Web Path ---

    # --- Refactor add_new_reward ---
    async def add_new_reward(self, reward_data):
        """Adds a new reward. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- add_new_reward called ---")
        if not self.username:
            print("Error: Username not set.")
            return None
        reward_data["username"] = self.username

        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print(f"Python (Web): Calling jsAddNewReward with data: {reward_data}")
            try:
                if not hasattr(js, "jsAddNewReward"):
                    print("Error (Web): jsAddNewReward function not found.")
                    return None
                result_proxy = await js.jsAddNewReward(reward_data)
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(f"Python (Web): Error from jsAddNewReward: {result['error']}")
                    return None
                elif result and result.get("data") is not None:
                    print("Python (Web): Reward added successfully.")
                    return (
                        result["data"][0]
                        if isinstance(result["data"], list) and result["data"]
                        else {}
                    )
                else:
                    print("Python (Web): Unexpected result from jsAddNewReward.")
                    return None
            except Exception as e:
                print(f"Python (Web): Error calling jsAddNewReward: {e}")
                traceback.print_exc()
                return None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print(f"Python (Non-Web): Adding reward via _make_request: {reward_data}")
            endpoint = "rewards"
            response_data = self._make_request("POST", endpoint, json=reward_data)
            if response_data is not None:
                print("Reward added successfully (Non-Web).")
                return response_data
            else:
                print("Failed to add reward (Non-Web).")
                return None
            # --- End Non-Web Path ---

    # --- Refactor mark_task_done ---
    async def mark_task_done(self, task_id, task_name):
        """Marks task done, adds history, increments medals. Uses JS SDK (web) or _make_request/_rpc (non-web)."""
        print(f"--- mark_task_done called for task ID: {task_id} ---")

        # Prepare history data (common)
        history_data = {
            "description": task_name,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        if self.username:
            history_data["username"] = self.username
        # user_id handled by RLS

        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            try:
                # 1. Add History
                print(
                    f"Python (Web): Step 1 - Calling jsAddTaskHistory: {history_data}"
                )
                if not hasattr(js, "jsAddTaskHistory"):
                    print("Error (Web): jsAddTaskHistory not found.")
                    return False, None
                hist_res_proxy = await js.jsAddTaskHistory(history_data)
                hist_res = hist_res_proxy.to_py()
                if not hist_res or hist_res.get("error"):
                    print(
                        f"Python (Web): Error adding task history: {hist_res.get('error') if hist_res else 'No response'}"
                    )
                    return False, None
                print("Python (Web): Step 1 - Task history added.")

                # 2. Delete Task
                print(f"Python (Web): Step 2 - Calling jsDeleteTask for ID: {task_id}")
                if not hasattr(js, "jsDeleteTask"):
                    print("Error (Web): jsDeleteTask not found.")
                    return False, None
                del_res_proxy = await js.jsDeleteTask(task_id)
                del_res = del_res_proxy.to_py()
                if not del_res or del_res.get("error"):
                    print(
                        f"Python (Web): Error deleting task: {del_res.get('error') if del_res else 'No response'}"
                    )
                    # Consider if rollback is needed/possible
                    return False, None
                print("Python (Web): Step 2 - Task deleted.")

                # 3. Increment Medals (RPC)
                print(
                    f"Python (Web): Step 3 - Calling jsUpdateMedalCountRpc by {MEDALS_PER_TASK}"
                )
                # Note: _update_medal_count_rpc is already refactored to use JS in web path
                new_medal_count = await self._update_medal_count_rpc(MEDALS_PER_TASK)
                print(
                    f"Python (Web): Step 3 Result - new_medal_count = {new_medal_count}"
                )

                if new_medal_count is None:
                    print(
                        "Python (Web): Warning - Task done/deleted, but medal update failed."
                    )
                    return True, None  # Partial success
                else:
                    print("Python (Web): Task processing finished successfully.")
                    return True, new_medal_count  # Full success

            except Exception as e:
                print(f"Python (Web): Error during mark_task_done sequence: {e}")
                traceback.print_exc()
                return False, None
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request/_rpc (Existing Logic) ---
            print("Python (Non-Web): Marking task done via _make_request...")
            # 1. Add History
            history_endpoint = "task_history"
            if self.user_id:
                history_data["user_id"] = (
                    self.user_id
                )  # Add if needed by non-web RLS/policy
            print(f"Step 1 (Non-Web): Sending task history data: {history_data}")
            history_response = self._make_request(
                "POST", history_endpoint, json=history_data
            )
            if history_response is None:
                print("Error adding task history (Non-Web). Aborting.")
                return False, None
            print("Step 1 (Non-Web): Task history added.")

            # 2. Delete Task
            task_endpoint = f"tasks?id=eq.{task_id}"
            print(f"Step 2 (Non-Web): Deleting task: {task_endpoint}")
            delete_success = self._make_request("DELETE", task_endpoint)
            if not delete_success:
                print(f"Error deleting task {task_id} (Non-Web).")
                return False, None
            print("Step 2 (Non-Web): Task deleted.")

            # 3. Increment Medals (RPC)
            print(f"Step 3 (Non-Web): Incrementing medals by {MEDALS_PER_TASK}")
            # _update_medal_count_rpc uses _make_request in non-web path
            new_medal_count = await self._update_medal_count_rpc(
                MEDALS_PER_TASK
            )  # Still await, as it's async now
            print(f"Step 3 Result (Non-Web): new_medal_count = {new_medal_count}")

            if new_medal_count is None:
                print("Warning (Non-Web): Task done/deleted, but medal update failed.")
                return True, None
            else:
                print("Task processing finished successfully (Non-Web).")
                return True, new_medal_count
            # --- End Non-Web Path ---

    # --- Refactor claim_reward ---
    async def claim_reward(self, reward_id, reward_name, reward_cost):
        """Claims reward, adds history, decrements medals. Uses JS SDK (web) or mixed (non-web)."""
        print(f"--- claim_reward started: {reward_name}, Cost: {reward_cost} ---")

        # 0. Check funds (get_medal_count is now async)
        current_medals = await self.get_medal_count()  # Await the async call
        print(f"claim_reward: Current medals check: {current_medals}")
        if current_medals is None:
            return False, "Error fetching medal count."
        if reward_cost > current_medals:
            msg = f"Not enough medals ({current_medals}) to claim reward costing {reward_cost}."
            print(f"claim_reward: {msg}")
            return False, msg
        print("claim_reward: Medal check passed.")

        # Prepare history data (common)
        history_data = {
            "description": reward_name,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "cost": reward_cost,
        }
        if self.username:
            history_data["username"] = self.username
        # user_id handled by RLS

        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            try:
                # 1. Add History
                print(
                    f"Python (Web): Step 1 - Calling jsAddRewardHistory: {history_data}"
                )
                if not hasattr(js, "jsAddRewardHistory"):
                    print("Error (Web): jsAddRewardHistory not found.")
                    return False, "History Error"
                hist_res_proxy = await js.jsAddRewardHistory(history_data)
                hist_res = hist_res_proxy.to_py()
                if not hist_res or hist_res.get("error"):
                    print(
                        f"Python (Web): Error adding reward history: {hist_res.get('error') if hist_res else 'No response'}"
                    )
                    return False, "Failed to record reward in history."
                print("Python (Web): Step 1 - Reward history added.")

                # 2. Delete Reward
                print(
                    f"Python (Web): Step 2 - Calling jsDeleteReward for ID: {reward_id}"
                )
                if not hasattr(js, "jsDeleteReward"):
                    print("Error (Web): jsDeleteReward not found.")
                    return False, "Delete Error"
                del_res_proxy = await js.jsDeleteReward(reward_id)
                del_res = del_res_proxy.to_py()
                if not del_res or del_res.get("error"):
                    print(
                        f"Python (Web): Error deleting reward: {del_res.get('error') if del_res else 'No response'}"
                    )
                    return False, "Failed to remove reward after claiming."
                print("Python (Web): Step 2 - Reward deleted.")

                # 3. Decrement Medals (RPC)
                print(
                    f"Python (Web): Step 3 - Calling jsUpdateMedalCountRpc by {-reward_cost}"
                )
                # _update_medal_count_rpc uses JS in web path
                new_medal_count = await self._update_medal_count_rpc(-reward_cost)
                print(
                    f"Python (Web): Step 3 Result - new_medal_count = {new_medal_count}"
                )

                if new_medal_count is None:
                    print(
                        "Python (Web): Warning - Reward claimed/deleted, but medal update failed."
                    )
                    return True, None  # Partial success
                else:
                    print(
                        f"Python (Web): Full success - Reward claimed. New count: {new_medal_count}"
                    )
                    return True, new_medal_count  # Full success

            except Exception as e:
                print(f"Python (Web): Error during claim_reward sequence: {e}")
                traceback.print_exc()
                return False, "Unexpected error during claim."
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request/_rpc (Existing Logic) ---
            print("Python (Non-Web): Claiming reward via _make_request...")
            # 1. Add History
            history_endpoint = "reward_history"
            if self.user_id:
                history_data["user_id"] = self.user_id  # Add if needed
            print(f"Step 1 (Non-Web): Sending reward history data: {history_data}")
            history_response = self._make_request(
                "POST", history_endpoint, json=history_data
            )
            if history_response is None:
                print("Error adding reward history (Non-Web). Aborting.")
                return False, "History Error"
            print("Step 1 (Non-Web): Reward history added.")

            # 2. Delete Reward
            reward_endpoint = f"rewards?id=eq.{reward_id}"
            print(f"Step 2 (Non-Web): Deleting reward: {reward_endpoint}")
            delete_success = self._make_request("DELETE", reward_endpoint)
            if not delete_success:
                print(f"Error deleting reward {reward_id} (Non-Web).")
                return False, "Delete Error"
            print("Step 2 (Non-Web): Reward deleted.")

            # 3. Decrement Medals (RPC)
            print(f"Step 3 (Non-Web): Decrementing medals by {reward_cost}")
            # _update_medal_count_rpc uses _make_request in non-web path
            new_medal_count = await self._update_medal_count_rpc(
                -reward_cost
            )  # Await async call
            print(f"Step 3 Result (Non-Web): new_medal_count = {new_medal_count}")

            if new_medal_count is None:
                print(
                    "Warning (Non-Web): Reward claimed/deleted, but medal update failed."
                )
                return True, None
            else:
                print(
                    f"Full success (Non-Web) - Reward claimed. New count: {new_medal_count}"
                )
                return True, new_medal_count
            # --- End Non-Web Path ---

    # --- Refactor get_task_history ---
    async def get_task_history(self):
        """Fetches task history. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- get_task_history called ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print("Python (Web): Calling jsGetTaskHistory...")
            try:
                if not hasattr(js, "jsGetTaskHistory"):
                    print("Error (Web): jsGetTaskHistory function not found.")
                    return []
                result_proxy = await js.jsGetTaskHistory()
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(
                        f"Python (Web): Error from jsGetTaskHistory: {result['error']}"
                    )
                    return []
                elif result and result.get("data") is not None:
                    history = result["data"]
                    print(f"Python (Web): Fetched {len(history)} task history items.")
                    return history if isinstance(history, list) else []
                else:
                    print("Python (Web): Unexpected result from jsGetTaskHistory.")
                    return []
            except Exception as e:
                print(f"Python (Web): Error calling jsGetTaskHistory: {e}")
                traceback.print_exc()
                return []
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print("Python (Non-Web): Getting task history via _make_request...")
            endpoint = "task_history"
            params = {"select": "*", "order": "timestamp.desc"}
            data = self._make_request("GET", endpoint, params=params)
            return data if isinstance(data, list) else []
            # --- End Non-Web Path ---

    # --- Refactor get_reward_history ---
    async def get_reward_history(self):
        """Fetches reward history. Uses JS SDK (web) or _make_request (non-web)."""
        print("--- get_reward_history called ---")
        if self.is_web_environment:
            # --- Web Path: Use JavaScript ---
            print("Python (Web): Calling jsGetRewardHistory...")
            try:
                if not hasattr(js, "jsGetRewardHistory"):
                    print("Error (Web): jsGetRewardHistory function not found.")
                    return []
                result_proxy = await js.jsGetRewardHistory()
                result = result_proxy.to_py()
                if result and result.get("error"):
                    print(
                        f"Python (Web): Error from jsGetRewardHistory: {result['error']}"
                    )
                    return []
                elif result and result.get("data") is not None:
                    history = result["data"]
                    print(f"Python (Web): Fetched {len(history)} reward history items.")
                    return history if isinstance(history, list) else []
                else:
                    print("Python (Web): Unexpected result from jsGetRewardHistory.")
                    return []
            except Exception as e:
                print(f"Python (Web): Error calling jsGetRewardHistory: {e}")
                traceback.print_exc()
                return []
            # --- End Web Path ---
        else:
            # --- Non-Web Path: Use _make_request ---
            print("Python (Non-Web): Getting reward history via _make_request...")
            endpoint = "reward_history"
            params = {"select": "*", "order": "timestamp.desc"}
            data = self._make_request("GET", endpoint, params=params)
            return data if isinstance(data, list) else []
            # --- End Non-Web Path ---

# c:\Users\nrmlc\OneDrive\Desktop\Reward_Yourself_ToDO\history_view.py
import flet as ft
from todo_view import ToDoList  # ToDoList methods are now async
import arrow


# history_view function itself remains synchronous
def history_view(page: ft.Page, todo_list: ToDoList):
    task_history_list = ft.ListView(
        expand=True, spacing=5, auto_scroll=True  # Enable auto_scroll
    )
    reward_history_list = ft.ListView(
        expand=True, spacing=5, auto_scroll=True  # Enable auto_scroll
    )

    # --- Make update_history_lists async ---
    async def update_history_lists():
        """Fetches and displays task and reward history asynchronously."""
        task_history_list.controls.clear()
        reward_history_list.controls.clear()

        if not todo_list:
            task_history_list.controls.append(ft.Text("Error: Not logged in."))
            reward_history_list.controls.append(ft.Text("Error: Not logged in."))
            if page.route == "/history":
                page.update()  # Update only if view is active
            return

        print("Updating history lists...")
        # Await the async calls
        task_history = await todo_list.get_task_history()
        reward_history = await todo_list.get_reward_history()

        # Populate Task History
        if task_history:
            for task in task_history:
                try:
                    timestamp_str = arrow.get(task.get("timestamp", "")).format(
                        "YYYY-MM-DD HH:mm"
                    )
                except (arrow.parser.ParserError, TypeError):
                    timestamp_str = "Invalid Date"
                description = task.get("description", "No description")
                task_history_list.controls.append(
                    ft.Text(
                        f"{timestamp_str} - Task: {description}", selectable=True
                    )  # Make text selectable
                )
        else:
            task_history_list.controls.append(ft.Text("No task history yet."))

        # Populate Reward History
        if reward_history:
            for reward in reward_history:
                try:
                    timestamp_str = arrow.get(reward.get("timestamp", "")).format(
                        "YYYY-MM-DD HH:mm"
                    )
                except (arrow.parser.ParserError, TypeError):
                    timestamp_str = "Invalid Date"
                description = reward.get("description", "No description")
                cost = reward.get("cost", "?")  # Get cost if available
                reward_history_list.controls.append(
                    ft.Text(
                        f"{timestamp_str} - Reward: {description} ({cost} medals)",
                        selectable=True,
                    )  # Make text selectable
                )
        else:
            reward_history_list.controls.append(ft.Text("No reward history yet."))

        print("History lists updated.")
        # Update the page only if this view is currently active
        if page.route == "/history":
            page.update()

    # --- End async modification ---

    # --- Initial population handled by on_connect ---
    # update_history_lists() # Remove direct call

    # Define async handler for refresh button if needed
    async def handle_refresh_click(e):
        await update_history_lists()

    view = ft.View(
        "/history",
        [
            ft.AppBar(
                title=ft.Text("History"),
                leading=ft.IconButton(
                    icon=ft.icons.ARROW_BACK,
                    tooltip="Back to Tasks",
                    on_click=lambda _: page.go("/"),
                ),
                # Optional: Add a refresh button
                actions=[
                    ft.IconButton(
                        icon=ft.icons.REFRESH,
                        tooltip="Refresh History",
                        on_click=handle_refresh_click,
                    )
                ],
            ),
            ft.Column(
                [
                    ft.Text("Task History", style=ft.TextThemeStyle.HEADLINE_SMALL),
                    task_history_list,
                    ft.Divider(height=20),
                    ft.Text("Reward History", style=ft.TextThemeStyle.HEADLINE_SMALL),
                    reward_history_list,
                ],
                expand=True,
                scroll=ft.ScrollMode.ADAPTIVE,
            ),
            # BottomAppBar added by main.py's route_change
        ],
        padding=10,
        # --- Add on_connect handler ---
        on_connect=lambda e: page.run_task(update_history_lists),
        # --- End modification ---
    )
    return view

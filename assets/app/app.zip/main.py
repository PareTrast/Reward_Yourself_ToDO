# c:\Users\nrmlc\OneDrive\Desktop\Reward_Yourself_ToDO\main.py
import flet as ft
import os
import sys
import json
import asyncio  # Import asyncio for web environment checks if needed

from calendar_view import build_calendar
from todo_view import ToDoList, MEDALS_PER_TASK
from user_manager import UserManager
from reward_view import reward_view
from history_view import history_view
import arrow
import time  # Keep time if needed elsewhere, otherwise remove
import config_loader


# --- Session file handling (remains synchronous) ---
def read_tokens_from_session():
    """Reads the access_token and refresh_token from session.json."""
    try:
        with open("session.json", "r") as file:
            content = file.read()
            if not content:
                return None, None
            session_data = json.loads(content)
            access_token = session_data.get("access_token")
            refresh_token = session_data.get("refresh_token")
            if isinstance(access_token, str) and isinstance(refresh_token, str):
                return access_token, refresh_token
            else:
                print("Invalid token format found in session.json.")
                return None, None
    except FileNotFoundError:
        return None, None
    except json.JSONDecodeError:
        print("Error decoding session.json.")
        return None, None
    except Exception as e:
        print(f"Error reading session.json: {e}")
        return None, None


def write_tokens_to_session(access_token, refresh_token):
    """Writes the access_token and refresh_token to session.json."""
    if not isinstance(access_token, str) or not isinstance(refresh_token, str):
        print("Error: Attempted to write non-string tokens to session.json.")
        return
    try:
        with open("session.json", "w") as file:
            json.dump(
                {"access_token": access_token, "refresh_token": refresh_token}, file
            )
        print("Tokens written to session.json.")
    except Exception as e:
        print(f"Error writing to session.json: {e}")


# --- Main Application Function ---
def main(page: ft.Page):
    if config_loader.CONFIG_ERROR:
        page.add(
            ft.Column(
                [
                    ft.Text(
                        "Application Configuration Error", size=20, color=ft.colors.RED
                    ),
                    ft.Text(config_loader.CONFIG_ERROR),
                    ft.Text("Please check config.json and build includes."),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            )
        )
        page.update()
        return

    page.title = "Reward Yourself"
    page.horizontal_alignment = ft.MainAxisAlignment.CENTER
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.theme_mode = ft.ThemeMode.SYSTEM

    # --- State Variables ---
    user_manager = UserManager(page)
    todo_list: ToDoList | None = None  # Use | None for clarity
    username: str | None = None
    selected_due_date = None
    is_web_environment = page.web
    current_medal_count_display_main = ft.Text(
        "Medals: -", tooltip="Your current medal balance"
    )

    # --- UI Elements (Shared/Persistent) ---
    # FilePicker is not used, can be removed if not needed elsewhere
    # file_picker = ft.FilePicker()
    # page.overlay.append(file_picker)

    # --- Token Management (remains synchronous) ---
    def _get_tokens():
        if page.web:
            try:
                access_token = page.client_storage.get("access_token")
                refresh_token = page.client_storage.get("refresh_token")
                if not access_token or not refresh_token:
                    return None, None
                if isinstance(access_token, str) and isinstance(refresh_token, str):
                    return access_token, refresh_token
                else:
                    page.client_storage.remove("access_token")
                    page.client_storage.remove("refresh_token")
                    return None, None
            except Exception as e:
                print(f"Error retrieving tokens from client storage: {e}")
                return None, None
        else:
            return read_tokens_from_session()

    def _clear_tokens():
        print("Clearing stored tokens...")
        if page.web:
            try:  # Add try-except for web storage too
                page.client_storage.remove("access_token")
                page.client_storage.remove("refresh_token")
            except Exception as e:
                print(f"Error clearing client storage: {e}")
        else:
            try:
                if os.path.exists("session.json"):
                    os.remove("session.json")
                    print("Removed session.json.")
            except OSError as e:
                print(f"Error removing session.json: {e}")

    def _store_tokens(acc_token, ref_token):
        print("Storing tokens...")
        if page.web:
            try:  # Add try-except for web storage
                page.client_storage.set("access_token", acc_token)
                page.client_storage.set("refresh_token", ref_token)
            except Exception as e:
                print(f"Error storing tokens to client storage: {e}")
        else:
            write_tokens_to_session(acc_token, ref_token)

    # --- Central Medal Count Update Function (Now Async) ---
    async def update_main_medal_display(new_count: int | None = None):
        """Fetches medal count if needed and updates the main view's UI text asynchronously.
        Does NOT call page.update() directly, but can be passed to page.run_task."""
        display_value = "Medals: Error"
        count_to_display = None

        if new_count is not None:
            print(f"Updating main medal display with provided count: {new_count}")
            count_to_display = new_count
        elif todo_list:
            print("Fetching medal count for main display update...")
            # Await the async call
            fetched_count = await todo_list.get_medal_count()
            if fetched_count is not None:
                count_to_display = fetched_count
            else:
                print("Failed to fetch medal count.")

        if count_to_display is not None:
            display_value = f"Medals: {count_to_display}"
        elif not todo_list:
            display_value = "Medals: N/A"

        current_medal_count_display_main.value = display_value
        print(f"Main medal display value set to: {display_value}")
        # Update the page if this task is running and the route is relevant
        # This might cause multiple updates, consider updating only where necessary
        if page.route == "/" or page.route == "/rewards" or page.route == "/history":
            page.update()

    # --- Authentication Logic ---
    # check_login remains mostly synchronous as it deals with non-web client/token checks
    # but the call to update medals needs to be scheduled.
    def check_login():
        """Checks login status, initializes ToDoList, returns True if logged in."""
        nonlocal username, todo_list
        access_token, refresh_token = _get_tokens()
        if not access_token or not refresh_token:
            return False

        # Supabase client interaction is only needed for non-web here
        supabase_client = None
        if not page.web:
            supabase_client = user_manager.get_supabase_client()
            if not supabase_client:
                print("Non-web: Failed to get supabase client.")
                _clear_tokens()
                return False
        elif (
            todo_list and not todo_list.access_token
        ):  # Web: ensure token is set if todo_list exists
            todo_list.set_access_token(access_token, refresh_token)

        # --- Web Login Check ---
        if page.web:
            # In web, we assume tokens are valid if they exist, as verification happens
            # during login/registration via JS. We need user_id and username.
            # We might need a JS function to get current user info if needed here.
            # For now, let's assume tokens imply logged in state for web.
            # We need to reconstruct username and user_id if possible.
            # This part is tricky without a JS call to get user.
            # Let's assume UserManager stored user_id/username on login/register.
            # OR, parse the JWT (less secure, complex).
            # --> Simplification: Assume if tokens exist, user is "logged in".
            # --> We need user_id for ToDoList methods though.
            # --> Let's fetch it via JS if needed, or store it on login.

            # Let's try fetching user info via JS on check_login for web
            async def get_web_user_info():
                nonlocal username, todo_list
                print("Web: Checking user session via JS...")
                if not hasattr(js, "jsGetUser"):
                    print("Web Error: jsGetUser function not found.")
                    return None, None
                try:
                    user_info_proxy = await js.jsGetUser()
                    user_info = user_info_proxy.to_py()
                    if user_info and user_info.get("user"):
                        user = user_info["user"]
                        user_id = user.get("id")
                        stored_username = user.get("user_metadata", {}).get("username")
                        if stored_username:
                            current_username = stored_username
                        elif user.get("email", "").endswith("@placeholder.com"):
                            current_username = user["email"].split("@")[0]
                        else:
                            current_username = (
                                f"User_{user_id[:5]}" if user_id else "Unknown"
                            )

                        print(
                            f"Web: User session valid. ID: {user_id}, Username: {current_username}"
                        )
                        return user_id, current_username
                    else:
                        print("Web: No active user session found via JS.")
                        return None, None
                except Exception as e:
                    print(f"Web: Error calling jsGetUser: {e}")
                    return None, None

            # Run the async JS check (this makes check_login inherently async if web)
            # This complicates route_change. Let's rethink.
            # Maybe check_login should ONLY check token existence,
            # and user_id/username are set during login/registration?

            # --- Revised Simpler Web Check ---
            print("Web: Assuming tokens exist means logged in.")
            # We still need user_id and username. Let's assume they are stored
            # or retrieved elsewhere (e.g., during login/registration).
            # If not, ToDoList operations might fail later.
            # For now, proceed, but this needs robust handling.
            if not username:  # If username wasn't set during login/registration
                # Attempt to retrieve from storage? Or require re-login?
                print("Web Warning: Username not available in check_login.")
                # Maybe try a quick JS call here? Or handle in route_change?
                pass  # Proceed cautiously

            if not todo_list:
                # Pass None for supabase_client in web environment
                todo_list = ToDoList(username or "WebUser", is_web_environment, None)
            # Ensure tokens are set in todo_list instance for web (might be redundant if JS handles it)
            todo_list.set_access_token(access_token, refresh_token)
            # We need user_id. If not available, many things break.
            # Let's assume it was stored or set previously.
            if not todo_list.user_id:
                print("Web Error: User ID not set in todo_list during check_login.")
                # Attempt to fetch via JS?
                # page.run_task(set_user_id_from_js()) # Example async task
                # For now, return False if user_id is missing?
                # return False # Or handle this state appropriately

            # Schedule medal update task
            page.run_task(update_main_medal_display)
            return True
            # --- End Revised Simpler Web Check ---

        # --- Non-Web Login Check (Original Logic) ---
        else:
            try:
                print("Non-Web: Verifying token...")
                try:
                    supabase_client.auth.set_session(access_token, refresh_token)
                except Exception as e:
                    print(f"Non-Web: Error setting session: {e}")
                    _clear_tokens()
                    return False

                user_response = supabase_client.auth.get_user()
                user = user_response.user
                if user:
                    print(f"Non-Web: Token valid for user ID: {user.id}")
                    stored_username = user.user_metadata.get("username")
                    if stored_username:
                        username = stored_username
                    elif user.email and "@placeholder.com" in user.email:
                        username = user.email.split("@")[0]
                    else:
                        username = f"User_{user.id[:5]}"

                    if not todo_list:
                        todo_list = ToDoList(
                            username, is_web_environment, supabase_client
                        )
                    elif not todo_list.supabase_client:
                        todo_list.supabase_client = supabase_client

                    todo_list.user_id = user.id
                    todo_list.set_access_token(access_token, refresh_token)
                    _store_tokens(access_token, refresh_token)
                    # Schedule medal update task
                    page.run_task(update_main_medal_display)
                    return True
                else:
                    print("Non-Web: set_session succeeded but get_user failed.")
                    _clear_tokens()
                    return False

            except Exception as e:
                print(f"Non-Web: Token invalid/expired ({e}). Attempting refresh...")
                try:
                    print("Non-Web: Attempting explicit refresh...")
                    # Ensure refresh_session is called correctly if needed
                    # Assuming auto-refresh might handle this, but explicit call:
                    refresh_response = supabase_client.auth.refresh_session(
                        refresh_token
                    )  # Pass refresh token
                    if not refresh_response or not refresh_response.session:
                        print("Non-Web: Explicit refresh failed.")
                        _clear_tokens()
                        return False

                    print("Non-Web: Explicit refresh successful, getting user again...")
                    # Use the new session from the refresh response
                    new_session = refresh_response.session
                    supabase_client.auth.set_session(
                        new_session.access_token, new_session.refresh_token
                    )
                    user_response_after_refresh = supabase_client.auth.get_user()
                    user = user_response_after_refresh.user

                    if user:
                        print("Non-Web: Refresh successful and token still valid.")
                        new_access_token = new_session.access_token
                        new_refresh_token = new_session.refresh_token

                        stored_username = user.user_metadata.get("username")
                        if stored_username:
                            username = stored_username
                        elif user.email and "@placeholder.com" in user.email:
                            username = user.email.split("@")[0]
                        else:
                            username = f"User_{user.id[:5]}"

                        if not todo_list:
                            todo_list = ToDoList(
                                username, is_web_environment, supabase_client
                            )
                        elif not todo_list.supabase_client:
                            todo_list.supabase_client = supabase_client

                        todo_list.user_id = user.id
                        todo_list.set_access_token(new_access_token, new_refresh_token)
                        _store_tokens(new_access_token, new_refresh_token)
                        page.run_task(update_main_medal_display)
                        return True
                    else:
                        print("Non-Web: Refresh succeeded but get_user still failed.")
                        _clear_tokens()
                        return False
                except Exception as refresh_e:
                    print(f"Non-Web: Error during refresh attempt: {refresh_e}")
                    _clear_tokens()
                    return False
            # --- End Non-Web Check ---

    # --- Make perform_login async ---
    async def perform_login(login_username, password, error_text_control):
        """Handles the login process asynchronously."""
        nonlocal username, todo_list
        error_text_control.value = ""
        page.update()

        if not login_username or not password:
            error_text_control.value = "Please enter username and password."
            page.update()
            return

        # Await the async call
        access_token, user_id, refresh_token = await user_manager.verify_user(
            login_username, password
        )

        if access_token and user_id and refresh_token:
            username = login_username
            supabase_client = None  # Client only needed for non-web
            if not page.web:
                supabase_client = user_manager.get_supabase_client()
                if not supabase_client:
                    error_text_control.value = (
                        "Error initializing application services."
                    )
                    page.update()
                    return
                # Set session in the non-web client *after* successful login
                try:
                    supabase_client.auth.set_session(access_token, refresh_token)
                    print("Session set in non-web client after login.")
                except Exception as e:
                    print(f"Error setting session after login (non-web): {e}")

            # Initialize ToDoList (pass None client for web)
            todo_list = ToDoList(username, is_web_environment, supabase_client)
            todo_list.set_access_token(access_token, refresh_token)
            todo_list.user_id = user_id
            _store_tokens(access_token, refresh_token)

            # Store user_id and username for web session persistence if needed
            if page.web:
                try:
                    page.client_storage.set("user_id", user_id)
                    page.client_storage.set("username", username)
                except Exception as e:
                    print(f"Web: Error storing user info to client storage: {e}")

            page.go("/")  # Triggers route_change, which updates medals
        else:
            error_text_control.value = "Login failed. Check username/password."
            _clear_tokens()  # Clear any potentially bad stored tokens
            page.update()

    # --- End async perform_login ---

    # --- Make perform_registration async ---
    async def perform_registration(reg_username, password, error_text_control):
        """Handles the registration process asynchronously."""
        nonlocal username, todo_list
        error_text_control.value = ""
        page.update()

        if not reg_username or not password:
            error_text_control.value = "Please enter username and password."
            page.update()
            return
        if len(password) < 6:
            error_text_control.value = "Password must be at least 6 characters."
            page.update()
            return

        # Await the async call
        access_token, user_id, refresh_token = await user_manager.register_user(
            reg_username, password
        )

        if access_token and user_id and refresh_token:
            username = reg_username
            supabase_client = None  # Client only needed for non-web
            if not page.web:
                supabase_client = user_manager.get_supabase_client()
                if not supabase_client:
                    error_text_control.value = (
                        "Error initializing application services after registration."
                    )
                    page.update()
                    return
                # Set session in the non-web client *after* successful registration
                try:
                    supabase_client.auth.set_session(access_token, refresh_token)
                    print("Session set in non-web client after registration.")
                except Exception as e:
                    print(f"Error setting session after registration (non-web): {e}")

            # Initialize ToDoList (pass None client for web)
            todo_list = ToDoList(username, is_web_environment, supabase_client)
            todo_list.set_access_token(access_token, refresh_token)
            todo_list.user_id = user_id
            _store_tokens(access_token, refresh_token)

            # Store user_id and username for web session persistence if needed
            if page.web:
                try:
                    page.client_storage.set("user_id", user_id)
                    page.client_storage.set("username", username)
                except Exception as e:
                    print(f"Web: Error storing user info to client storage: {e}")

            page.go("/")  # Triggers route_change, which updates medals
        else:
            error_text_control.value = (
                "Registration failed. User might already exist or invalid input."
            )
            _clear_tokens()
            page.update()

    # --- End async perform_registration ---

    # perform_logout remains synchronous (supabase-py sync sign_out is sync)
    def perform_logout():
        """Logs the user out and clears session."""
        nonlocal username, todo_list
        print("Performing logout...")

        # Sign out on web using JS
        if page.web:
            if hasattr(js, "jsSignOut"):
                # Don't necessarily need to await this if we're navigating away immediately
                page.run_task(js.jsSignOut)  # Run async JS signout in background
            else:
                print("Web Warning: jsSignOut function not found.")
        # Sign out for non-web
        elif user_manager.public_supabase:  # Use public client if available
            try:
                user_manager.public_supabase.auth.sign_out()
                print("Signed out from Supabase (non-web).")
            except Exception as e:
                print(f"Error during Supabase sign out (non-web): {e}")

        _clear_tokens()
        username = None
        todo_list = None
        current_medal_count_display_main.value = "Medals: N/A"
        # No page update needed here as page.go handles it
        page.go("/login")

    # --- View Definitions ---
    def show_login_view():
        username_input = ft.TextField(
            label="Username", autofocus=True, on_submit=lambda e: password_input.focus()
        )
        password_input = ft.TextField(
            label="Password",
            password=True,
            can_reveal_password=True,
            # Use page.run_task for on_submit with async function
            on_submit=lambda e: page.run_task(
                perform_login(
                    username_input.value.strip(),
                    password_input.value,
                    error_text,
                )
            ),
        )
        error_text = ft.Text("", color=ft.colors.RED)

        # Define async handler for button click
        async def handle_login_click(e):
            await perform_login(
                username_input.value.strip(),
                password_input.value,
                error_text,
            )

        return ft.View(
            "/login",
            [
                ft.AppBar(title=ft.Text("Login"), automatically_imply_leading=False),
                ft.Column(
                    [
                        username_input,
                        password_input,
                        ft.ElevatedButton(
                            "Login",
                            # Assign the async handler directly
                            on_click=handle_login_click,
                        ),
                        ft.TextButton(
                            "Register", on_click=lambda _: page.go("/register")
                        ),
                        error_text,
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=20,
                    width=300,
                ),
            ],
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

    def show_register_view():
        register_username = ft.TextField(
            label="Username",
            autofocus=True,
            on_submit=lambda e: register_password.focus(),
        )
        register_password = ft.TextField(
            label="Password (min 6 chars)",
            password=True,
            can_reveal_password=True,
            # Use page.run_task for on_submit with async function
            on_submit=lambda e: page.run_task(
                perform_registration(
                    register_username.value.strip(),
                    register_password.value,
                    error_text,
                )
            ),
        )
        error_text = ft.Text("", color=ft.colors.RED)

        # Define async handler for button click
        async def handle_register_click(e):
            await perform_registration(
                register_username.value.strip(),
                register_password.value,
                error_text,
            )

        return ft.View(
            "/register",
            [
                ft.AppBar(title=ft.Text("Register")),
                ft.Column(
                    [
                        register_username,
                        register_password,
                        ft.ElevatedButton(
                            "Register",
                            # Assign the async handler directly
                            on_click=handle_register_click,
                        ),
                        error_text,
                    ],
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    spacing=20,
                    width=300,
                ),
            ],
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )

    # --- Modify show_main_view and its inner functions ---
    def show_main_view():
        """Builds and displays the main ToDo view."""
        nonlocal selected_due_date

        calendar_container = ft.Container(content=build_calendar(page), padding=10)
        task_input = ft.TextField(
            label="New Task",
            expand=True,
            # Use page.run_task for on_submit with async function
            on_submit=lambda e: page.run_task(add_task(e)),
        )
        task_list_view = ft.ListView(expand=True, spacing=5, auto_scroll=True)
        selected_date_text = ft.Text("Due Date: None")

        # Date handlers remain synchronous
        def handle_date_change_main(e):
            nonlocal selected_due_date
            selected_due_date = e.control.value
            selected_date_text.value = (
                f"Due: {selected_due_date.strftime('%Y-%m-%d')}"
                if selected_due_date
                else "Due Date: None"
            )
            page.update()

        def handle_date_dismissal_main(e):
            print("DatePicker dismissed.")

        # Make update_task_list async
        async def update_task_list():
            """Refreshes the task list asynchronously."""
            task_list_view.controls.clear()
            if not todo_list:
                task_list_view.controls.append(ft.Text("Error: Not logged in."))
                if page.route == "/":
                    page.update()  # Update only if view is active
                return

            print("Refreshing task list...")
            tasks = await todo_list.get_all_tasks()  # Await async call
            if tasks:
                for task in tasks:
                    task_id, task_name, due_date_str = (
                        task.get("id"),
                        task.get("task", "Unnamed"),
                        task.get("due_date"),
                    )
                    if task_id is None:
                        continue

                    # Define async handler for mark done button
                    async def handle_mark_done_click(e, tid=task_id, tname=task_name):
                        await mark_done(tid, tname)

                    due_date_display = f" (Due: {due_date_str})" if due_date_str else ""
                    task_list_view.controls.append(
                        ft.Row(
                            [
                                ft.Text(
                                    f"{task_name}{due_date_display}",
                                    expand=True,
                                    tooltip=task_name,
                                ),
                                ft.IconButton(
                                    ft.icons.CHECK_CIRCLE_OUTLINE,
                                    tooltip="Mark as Done",
                                    # Use the async handler
                                    on_click=handle_mark_done_click,
                                    icon_color=ft.colors.GREEN_ACCENT_700,
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        )
                    )
            else:
                task_list_view.controls.append(ft.Text("No tasks yet!"))
            print("Task list refresh logic completed.")
            if page.route == "/":
                page.update()  # Update only if view is active

        # Make mark_done async
        async def mark_done(task_id, task_name):
            """Handles marking a task as done asynchronously."""
            print(f"Marking task done: ID={task_id}, Name={task_name}")
            if todo_list:
                # Await the async call
                success, returned_new_count = await todo_list.mark_task_done(
                    task_id, task_name
                )
                if success:
                    page.snack_bar = ft.SnackBar(
                        ft.Text(
                            f"Task '{task_name}' completed! (+{MEDALS_PER_TASK} Medals)"
                        )
                    )
                    page.snack_bar.open = True
                    # Schedule updates instead of awaiting them directly in handler
                    page.run_task(update_task_list)
                    page.run_task(
                        update_main_medal_display(new_count=returned_new_count)
                    )
                else:
                    page.snack_bar = ft.SnackBar(
                        ft.Text("Error completing task or updating medals.")
                    )
                    page.snack_bar.open = True
                page.update()  # Show snackbar
            else:
                print("Error: todo_list not available in mark_done.")

        # Make add_task async
        async def add_task(e):
            """Handles adding a new task asynchronously."""
            nonlocal selected_due_date
            if todo_list:
                task_text = task_input.value.strip()
                if task_text:
                    due_date_str = (
                        selected_due_date.strftime("%Y-%m-%d")
                        if selected_due_date
                        else None
                    )
                    new_task_data = {
                        "task": task_text,
                        "done": False,
                        "due_date": due_date_str,
                    }
                    # Await the async call
                    added_task = await todo_list.add_new_task(new_task_data)
                    if added_task is not None:  # Check for None on failure
                        task_input.value = ""
                        selected_due_date = None
                        selected_date_text.value = "Due Date: None"
                        task_input.focus()
                        # Schedule update instead of awaiting
                        page.run_task(update_task_list)
                        page.snack_bar = ft.SnackBar(ft.Text("Task added!"))
                        page.snack_bar.open = True
                    else:
                        page.snack_bar = ft.SnackBar(ft.Text("Error adding task."))
                        page.snack_bar.open = True
                    page.update()  # Show snackbar, clear inputs
                else:
                    page.snack_bar = ft.SnackBar(ft.Text("Please enter a task."))
                    page.snack_bar.open = True
                    task_input.focus()
                    page.update()
            else:
                print("Error: todo_list not available in add_task.")

        # Define async handler for refresh button
        async def handle_refresh_medals(e):
            await update_main_medal_display()
            # page.update() # update_main_medal_display now calls page.update()

        # Define async handler for add button
        async def handle_add_task_click(e):
            await add_task(e)

        # Initial task list load handled by on_connect

        view = ft.View(
            "/",
            [
                ft.AppBar(
                    title=ft.Text("Reward Yourself - ToDo"),
                    actions=[
                        current_medal_count_display_main,
                        ft.IconButton(
                            ft.icons.REFRESH,
                            tooltip="Refresh Medals",
                            # Assign async handler
                            on_click=handle_refresh_medals,
                        ),
                        ft.IconButton(
                            ft.icons.LOGOUT,
                            tooltip="Logout",
                            on_click=lambda _: perform_logout(),  # Logout is sync
                        ),
                    ],
                ),
                ft.Column(
                    [
                        calendar_container,
                        ft.Row(
                            [
                                task_input,
                                ft.IconButton(
                                    ft.icons.CALENDAR_MONTH,
                                    tooltip="Pick Due Date",
                                    on_click=lambda e: page.open(
                                        ft.DatePicker(
                                            first_date=arrow.now().datetime,
                                            last_date=arrow.now()
                                            .shift(years=+5)
                                            .datetime,
                                            help_text="Select task due date",
                                            on_change=handle_date_change_main,
                                            on_dismiss=handle_date_dismissal_main,
                                        )
                                    ),
                                ),
                                ft.IconButton(
                                    ft.icons.ADD_CIRCLE,
                                    tooltip="Add Task",
                                    # Assign async handler
                                    on_click=handle_add_task_click,
                                    icon_color=ft.colors.GREEN,
                                ),
                            ],
                            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                        ),
                        selected_date_text,
                        ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                        ft.Text("Tasks", style=ft.TextThemeStyle.HEADLINE_SMALL),
                        task_list_view,  # Populated by update_task_list
                    ],
                    expand=True,
                    scroll=ft.ScrollMode.ADAPTIVE,
                ),
            ],
            padding=10,
            bottom_appbar=build_bottom_app_bar("/"),
            # Add on_connect to load tasks when view is shown
            on_connect=lambda e: page.run_task(update_task_list),
        )
        return view

    # --- End modification ---

    # --- Navigation ---
    # build_bottom_app_bar remains synchronous
    def build_bottom_app_bar(current_route):
        return ft.BottomAppBar(
            bgcolor=ft.colors.BLUE_GREY_700,
            shape=ft.NotchShape.CIRCULAR,
            content=ft.Row(
                controls=[
                    ft.IconButton(
                        ft.icons.CHECK_BOX_ROUNDED,
                        tooltip="Tasks",
                        icon_color=ft.colors.WHITE,
                        selected=(current_route == "/"),
                        on_click=lambda _: page.go("/"),
                    ),
                    ft.Container(expand=True),
                    ft.IconButton(
                        ft.icons.STAR_RATE_ROUNDED,
                        tooltip="Rewards",
                        icon_color=ft.colors.WHITE,
                        selected=(current_route == "/rewards"),
                        on_click=lambda _: page.go("/rewards"),
                    ),
                    ft.IconButton(
                        ft.icons.HISTORY,
                        tooltip="History",
                        icon_color=ft.colors.WHITE,
                        selected=(current_route == "/history"),
                        on_click=lambda _: page.go("/history"),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_AROUND,
            ),
        )

    # --- Modified route_change (remains synchronous, schedules async tasks) ---
    def route_change(route):
        print(f"Route change requested: {page.route}")
        current_route = page.route  # Use page.route which reflects the target
        page.views.clear()

        # check_login is synchronous (but schedules async medal update)
        is_logged_in = check_login()

        target_view = None

        if not is_logged_in:
            # Handle logged-out routing
            if current_route not in ["/login", "/register"]:
                print("Not logged in, redirecting to /login")
                page.route = "/login"  # Ensure route is set correctly for next check
                target_view = show_login_view()
            elif current_route == "/login":
                target_view = show_login_view()
            else:  # current_route == "/register"
                target_view = show_register_view()
            current_medal_count_display_main.value = (
                "Medals: N/A"  # Update display value directly
            )
        else:
            # Handle logged-in routing
            if current_route in ["/login", "/register"]:
                print("Logged in, redirecting from auth page to /")
                page.route = "/"  # Ensure route is set correctly
                current_route = "/"  # Update local variable for view building

            # Build the target view based on the route
            if current_route == "/rewards":
                # reward_view itself is sync, but takes the async trigger function
                view = reward_view(
                    page, todo_list, lambda: page.run_task(update_main_medal_display())
                )
                view.bottom_appbar = build_bottom_app_bar(current_route)
                target_view = view
            elif current_route == "/history":
                # history_view itself is sync, but takes the async trigger function
                view = history_view(
                    page, todo_list
                )  # history_view needs update for async
                view.bottom_appbar = build_bottom_app_bar(current_route)
                target_view = view
            else:  # Default to main view
                target_view = show_main_view()

            # Schedule medal update when navigating while logged in
            page.run_task(update_main_medal_display())

        # Add the determined view
        if target_view:
            page.views.append(target_view)
        else:
            # Fallback if something went wrong
            print("Error: No target view determined, falling back to login.")
            page.views.append(show_login_view())

        page.update()  # Update the page to show the new view

    # --- End modification ---

    # view_pop remains synchronous
    def view_pop(view):
        print(f"View popped: {view.route}")
        page.views.pop()
        top_view = page.views[-1] if page.views else None
        target_route = top_view.route if top_view else "/login"
        print(f"Navigating back to: {target_route}")
        # page.go triggers route_change, which handles view updates
        page.go(target_route)

    # --- App Initialization ---
    page.on_route_change = route_change
    page.on_view_pop = view_pop
    print("App initializing...")
    # Initial navigation triggers route_change
    page.go(page.route if page.route else "/")


# --- Run the App ---
if __name__ == "__main__":
    # os.environ["FLET_FORCE_WEB_SOCKETS"] = "true" # Usually not needed unless specific issues
    ft.app(
        target=main,
        # export_asgi_app=True, # Only needed for specific ASGI deployments
        assets_dir="assets",
        view=ft.AppView.FLET_APP_WEB,  # Use FLET_APP_WEB for easier debugging
        # Or ft.AppView.WEB_BROWSER
    )

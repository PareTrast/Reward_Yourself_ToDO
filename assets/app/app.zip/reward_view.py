# c:\Users\nrmlc\OneDrive\Desktop\Reward_Yourself_ToDO\reward_view.py
import flet as ft
from todo_view import ToDoList
import os


# --- Update function signature (remains the same) ---
def reward_view(
    page: ft.Page, todo_list: ToDoList, trigger_main_medal_update: callable
):
    # --- End modification ---

    reward_list_view = ft.ListView(
        expand=True, spacing=10, padding=20, auto_scroll=True
    )
    reward_input = ft.TextField(label="New Reward", expand=True)
    medal_cost_input = ft.TextField(
        label="Medal Cost",
        keyboard_type=ft.KeyboardType.NUMBER,
        expand=True,
        input_filter=ft.InputFilter(
            allow=True, regex_string=r"[0-9]", replacement_string=""
        ),
    )

    # --- Modify refresh_reward_list to be async ---
    async def refresh_reward_list():
        """Refreshes the list of rewards asynchronously."""
        reward_list_view.controls.clear()
        if not todo_list:
            reward_list_view.controls.append(ft.Text("Error: Not logged in."))
            # No page update here, let caller handle
            return

        print("Refreshing reward list...")

        # Call the async method
        rewards = await todo_list.get_all_rewards()

        if rewards:
            for reward in rewards:
                reward_id, reward_name, cost = (
                    reward.get("id"),
                    reward.get("reward", "Unnamed"),
                    reward.get("medal_cost", 0),
                )
                if reward_id is None:
                    continue

                # --- Define async handler for claim button ---
                # This is needed because the lambda needs to await claim_reward
                async def handle_claim_click(
                    e, rid=reward_id, rname=reward_name, rcost=cost
                ):
                    await claim_reward(rid, rname, rcost)

                # --- End async handler ---

                reward_list_view.controls.append(
                    ft.Row(
                        [
                            ft.Text(
                                f"{reward_name} - {cost} medals",
                                expand=True,
                                tooltip=reward_name,
                            ),
                            ft.ElevatedButton(
                                "Claim",
                                tooltip=f"Claim for {cost} medals",
                                # Use the new async handler
                                on_click=handle_claim_click,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    )
                )
        else:
            reward_list_view.controls.append(ft.Text("No rewards available."))
        # Don't call page.update() here, let the caller handle it
        print("Reward list refresh logic completed.")
        # If the view is currently visible, update the page to show changes
        if page.route == "/rewards":
            page.update()

    # --- End modification ---

    # --- Modify add_reward to be async ---
    async def add_reward(e):
        """Handles adding a new reward asynchronously."""
        if todo_list:
            reward_text = reward_input.value.strip()
            cost_text = medal_cost_input.value.strip()
            if reward_text and cost_text.isdigit():
                cost = int(cost_text)
                new_reward_data = {"reward": reward_text, "medal_cost": cost}
                # Call the async method
                added_reward = await todo_list.add_new_reward(new_reward_data)
                if added_reward is not None:  # Check for None explicitly on failure
                    reward_input.value = ""
                    medal_cost_input.value = ""
                    reward_input.focus()
                    # No need to await refresh here, it will update the page itself
                    page.run_task(refresh_reward_list)
                    page.snack_bar = ft.SnackBar(ft.Text("Reward added!"))
                    page.snack_bar.open = True
                else:
                    page.snack_bar = ft.SnackBar(ft.Text("Error adding reward."))
                    page.snack_bar.open = True
                page.update()  # Update page after add action (shows snackbar, clears inputs)
            else:
                page.snack_bar = ft.SnackBar(
                    ft.Text("Please enter a valid reward and numeric medal cost.")
                )
                page.snack_bar.open = True
                if not reward_text:
                    reward_input.focus()
                else:
                    medal_cost_input.focus()
                page.update()  # Update page for validation error
        else:
            print("Error: todo_list not available in add_reward.")
            page.snack_bar = ft.SnackBar(
                ft.Text("Error: Not logged in.")
            )  # Add snackbar feedback
            page.snack_bar.open = True
            page.update()

    # --- End modification ---

    # --- Modify claim_reward to be async ---
    async def claim_reward(reward_id, reward_name, reward_cost):
        """Event handler for the claim button (now async)."""
        print(
            f"Attempting to claim reward via UI: {reward_name} (ID: {reward_id}), Cost: {reward_cost}"
        )
        if todo_list:
            # Call the async method
            success, result_data = await todo_list.claim_reward(
                reward_id, reward_name, reward_cost
            )

            message = ""
            if success:
                new_count = result_data
                message = f"Reward '{reward_name}' claimed!"
                if new_count is None:
                    message = f"Reward '{reward_name}' claimed! (Medal update may have failed, refreshing count...)"
                print(f"Claim successful: {message}")
                # No need to await refresh here, it will update the page itself
                page.run_task(refresh_reward_list)  # Refresh list only on success
            else:
                error_message = result_data
                message = f"Claim failed: {error_message}"
                print(message)
                # Don't refresh list on failure

            page.snack_bar = ft.SnackBar(ft.Text(message))
            page.snack_bar.open = True

            # Trigger update of the main medal display (this function itself is synchronous)
            trigger_main_medal_update()

            page.update()  # Show snackbar and trigger medal display update
        else:
            print("Error: todo_list object not available when trying to claim reward.")
            page.snack_bar = ft.SnackBar(ft.Text("Error: Not logged in."))
            page.snack_bar.open = True
            page.update()

    # --- End modification ---

    # Button now calls the async add_reward handler
    add_reward_button = ft.ElevatedButton("Add Reward", on_click=add_reward)

    # --- Initial population handled by on_connect ---

    view = ft.View(
        "/rewards",
        [
            ft.AppBar(
                title=ft.Text("Rewards"),
                leading=ft.IconButton(
                    icon=ft.icons.ARROW_BACK,
                    tooltip="Back to Tasks",
                    on_click=lambda _: page.go("/"),
                ),
                actions=[],  # Actions removed as per previous step
            ),
            ft.Column(
                [
                    ft.Row(
                        [reward_input, medal_cost_input, add_reward_button],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    ),
                    ft.Divider(height=10, color=ft.colors.TRANSPARENT),
                    ft.Text(
                        "Available Rewards", style=ft.TextThemeStyle.HEADLINE_SMALL
                    ),
                    reward_list_view,  # ListView is populated by refresh_reward_list
                ],
                expand=True,
                scroll=ft.ScrollMode.ADAPTIVE,
            ),
            # bottom_appbar should be added by main.py's route_change
        ],
        padding=10,
        # --- Add an on_connect handler to trigger initial load ---
        # This ensures the list is populated when the view becomes active
        on_connect=lambda e: page.run_task(refresh_reward_list),
        # --- End modification ---
    )
    return view

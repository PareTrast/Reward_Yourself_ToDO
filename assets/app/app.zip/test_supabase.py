import os
from supabase import create_client, Client
from dotenv import load_dotenv
from postgrest import APIError

load_dotenv()

SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
SUPABASE_ANON_KEY = os.environ.get("SUPABASE_ANON_KEY")

print(SUPABASE_URL, SUPABASE_KEY, SUPABASE_ANON_KEY)

"""# Initialize Supabase client with the anon key
url = SUPABASE_URL
key = SUPABASE_KEY
supabase: Client = create_client(url, key)

# Replace with your test user's credentials
test_user_email = "tester728@placeholder.com"  # Replace with the test user's email
test_user_password = "tester728"  # Replace with the test user's password

# Sign in the test user
try:
    response = supabase.auth.sign_in_with_password(
        {"email": test_user_email, "password": test_user_password}
    )
    if response.session:
        print("Successfully signed in test user!")
        user_id = response.session.user.id
        print(f"Test user ID: {user_id}")
        access_token = response.session.access_token
        supabase.headers = {"Authorization": f"Bearer {access_token}"}
    else:
        print("Sign in failed:", response.error)
        exit()
except Exception as e:
    print(f"An error occurred during sign in: {e}")
    exit()

# Data to insert
data = {
    "username": "tester728@placeholder.com",
    "description": "Completed task XYZ",
    "timestamp": "2023-10-01T12:00:00Z",
    "user_id": user_id,  # Use the user_id from the session
}

print(data["username"], data["description"], data["timestamp"])
# Insert data into task_history table
try:
    response = supabase.table("task_history").insert(data).execute()

    # Check the response
    if response.status_code == 201:
        print("Insert successful:", response.data)
    else:
        print("Insert failed:", response.error)
except APIError as e:
    print(f"Supabase API Error: {e}")
    print(f"Error details: {e.details}")
    print(f"Error hint: {e.hint}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")"""
